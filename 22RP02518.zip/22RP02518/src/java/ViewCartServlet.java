package com.example;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

@WebServlet("/view-cart")
public class ViewCartServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<String> cart = getCartFromCookies(request.getCookies());

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Your Shopping Cart</h2>");
        out.println("<ul>");

        if (!cart.isEmpty()) {
            for (String item : cart) {
                out.println("<li>" + item + "</li>");
            }
        } else {
            out.println("<li>Your cart is empty.</li>");
        }

        out.println("</ul>");
        out.println("<form action='clear-cart' method='post'>");
        out.println("<button type='submit'>Clear Cart</button>");
        out.println("</form>");
        out.println("</body></html>");
        out.println("<a href='index.html'>Back to Shopping</a>");
    }

    private ArrayList<String> getCartFromCookies(Cookie[] cookies) {
        ArrayList<String> cart = new ArrayList<>();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("cart".equals(cookie.getName())) {
                    String[] items = cookie.getValue().split(",");
                    for (String item : items) {
                        if (!item.isEmpty()) { // Avoid adding empty items
                            cart.add(item);
                        }
                    }
                }
            }
        }
        return cart;
    }
    
}
